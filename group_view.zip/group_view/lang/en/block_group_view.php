<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Group View';
$string['group_view:addinstance'] = 'Add a new Group View block';
$string['group_view:myaddinstance'] = 'Add a new Group View block to the My Moodle page';

?>
