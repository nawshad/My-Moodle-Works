<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once('../../config.php');
global $DB;

$userid=$_GET['user_id'];
$groupid=$_GET['group_id'];

$users = $DB->get_records_sql('
    SELECT  mu.id as id, (mu.lastname||\',\'||mu.firstname) as partners_name 
    FROM    mdl_groups_members mgm, mdl_groups mg, mdl_user mu
    WHERE  groupid 
    in (SELECT groupid
	FROM   mdl_groups_members mgm
	WHERE  userid=?)
    AND mgm.groupid=mg.id
    AND mgm.userid=mu.id
    AND mgm.userid<>?
    AND groupid=?
    GROUP BY mu.id, partners_name 
    ORDER BY partners_name ASC', array($userid,$userid,$groupid));


foreach ($users as $user) {
    $display_string .= 
        '<div id= '.$user->id.'><i>'.$user->partners_name.'<i></div>';
      
}

echo $display_string;


