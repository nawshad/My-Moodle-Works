<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once($CFG->libdir . '/pagelib.php');

class block_group_view extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_group_view');
    }
    // The PHP tag and the curly bracket for the class definition 
    // will only be closed after there is another function added in the next section. 
    
    function get_required_javascript() {
        parent::get_required_javascript();
 
        $this->page->requires->jquery();
        $this->page->requires->jquery_plugin('ui');
        $this->page->requires->jquery_plugin('ui-css');
    }
    
    public function get_content() {
       global $USER, $DB, $CFG, $PAGE;
       $userid = $USER->id;
       $root = $CFG->wwwroot;
            
       if ($this->content !== null) {
           return $this->content;
       }
        
       $courses = $DB->get_records_sql('
           SELECT distinct mc.id, mc.fullname as course
           FROM   mdl_groups_members mgm, mdl_groups mg, mdl_course mc	
           WHERE  userid=?
           AND    mg.id=mgm.groupid
           AND    mg.courseid=mc.id
           ORDER BY course ASC', array($userid));
       
        $courses_ids=array(); 
        foreach($courses as $course){
            $courses_ids[$course->course]=$course->id;
        }  
        
        $jsonObject=json_encode($courses_ids);
         
        $this->content         =  new stdClass;
        $this->content->footer = '';
        
        if (empty($this->instance)) {
            $this->content->text   = '';
            return $this->content;
        }
        
        $PAGE->requires->js( new moodle_url($root. '/blocks/group_view/js/modal.js'));
        
        $this->content->text  .=
             '<div id="gv_block_div">
                <a href="javascript:void(0)" onclick="pop('.htmlspecialchars($jsonObject).', \''.$root.'\', '.$userid.')">Click Here</a> 
             </div>';  
        
        return $this->content;                                            
  }
  
  function applicable_formats() {
        return array('all' => true);
  } 
}  
   
