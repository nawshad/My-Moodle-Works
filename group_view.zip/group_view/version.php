<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version = 2013051712;  // YYYYMMDDHH (year, month, day, 24-hr time)
$plugin->requires = 2012112900; // YYYYMMDDHH (This is the release version for Moodle 2.0)
$plugin->component = 'block_group_view';

