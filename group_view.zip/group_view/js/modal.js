/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */   
function close_cover() {  
    document.getElementById("translucentDiv").parentNode.removeChild(document.getElementById("translucentDiv"));   
} 
function close_pop() {  
    document.getElementById("popupDiv").parentNode.removeChild(document.getElementById("popupDiv")); 
    close_cover();
} 

function pop(coursesInfo,root,userid) {
    //integrating bootstrap
    /*var insert_this = "<div id='translucentDiv'>\
                        <div id='popup'>\
                        <h2>"+userid+"</h2>";
    
    $.magnificPopup.open({
        items: {
            src: insert_this, // '#moodle_test_modal',
            type: 'inline',
            removalDelay: 300,
            // Class that is added to popup wrapper and background
            // make it unique to apply your CSS animations just to this exact popup
            mainClass: 'mfp-fade',
        },

        closeOnContentClick: false,
        showCloseBtn: true
    });*/
       
    //Creating translucent cover, a child of parent document
    var coverdiv = document.createElement("div");
    coverdiv.id = "translucentDiv";
    document.body.appendChild(coverdiv);

    //Creating popupDiv, a child of the parent document
    var objdiv = document.createElement("div");
    objdiv.id = "popupDiv";
    objdiv.innerHTML="<b>Group View</b>";
    //coverdiv.appendChild(objdiv);
    document.body.appendChild(objdiv);

    //Creating mainCanvasDiv, a child of popupDiv 
    var mainCanvas = document.createElement("div");
    mainCanvas.id = "mainCanvasDiv";
    objdiv.appendChild(mainCanvas); 

    //Creating courseViewDiv child of mainCanvasDiv
    var courseView = document.createElement("div");
    courseView.id = "courseViewDiv";
    mainCanvas.appendChild(courseView); 

     //Creating groupViewDiv child of mainCanvasDiv
    var groupView = document.createElement("div");
    groupView.id = "groupViewDiv";
    mainCanvas.appendChild(groupView); 

     //Creating userViewDiv child of mainCanvasDiv
    var userView = document.createElement("div");
    userView.id = "userViewDiv";
    mainCanvas.appendChild(userView); 

    //Creating coursesTitleDiv, a child of mainCanvasDiv
    var coursesTitle = document.createElement("div");
    coursesTitle.id = "coursesTitleDiv";
    coursesTitle.innerHTML="<b>Courses</b>";
    mainCanvas.appendChild(coursesTitle);

     //Creating groupsTitleDiv, a child of mainCanvasDiv
    var groupsTitle = document.createElement("div");
    groupsTitle.id = "groupsTitleDiv";
    groupsTitle.innerHTML="<b>Groups</b>";
    mainCanvas.appendChild(groupsTitle); 

    //Creating usersTitleDiv, a child of mainCanvasDiv
    var usersTitle = document.createElement("div");
    usersTitle.id = "usersTitleDiv";
    usersTitle.innerHTML="<b>Users</b>";
    mainCanvas.appendChild(usersTitle); 

    //Creating buttonDiv of popupDiv
    var buttonnode= document.createElement("div");
    buttonnode.id="close-thik";
    objdiv.appendChild(buttonnode);

    buttonnode.onclick=close_pop;

    //Closing all on pressing ESC
    $(document).keyup(function(e) {
        if (e.keyCode == 27) { 
            close_pop();
        }
    });
    //Closing if clicked on coverDiv
    $("#translucentDiv").click(function() {
        close_pop();
    });
    //Generate coursesViewDiv with name of the courses
    genCoursesViewData(coursesInfo,root,userid); 
}

function addElement(divName,id,coursename,root,userid) { 
    var ni = document.getElementById(divName);
    var newdiv = document.createElement('div');
    var divIdName = "courseDiv"+id;

    newdiv.setAttribute('id',divIdName);
    newdiv.innerHTML = '<a href=\'javascript:void(0)\' onclick=genGroups('+userid+',\''+root+'\',\''+divIdName+'\','+id+')>'+coursename+'</a>';
    ni.appendChild(newdiv);
}

function genCoursesViewData(coursesInfo,root,userid) {  
    for(key in coursesInfo) {
        addElement("courseViewDiv",coursesInfo[key],key,root,userid);
    }   
}

function getGroupsAjaxFunction(userid, root, courseid) {
    var ajaxRequest;// The variable that makes Ajax possible!
    try {
        //Opera 8.0+, Firefox, Safari
        ajaxRequest = new XMLHttpRequest();
    }
    catch (e) {
       // Internet Explorer Browsers
        try{
            ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (e) {
            try {
                ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (e) {
             // Something went wrong
                alert("Your browser broke!");
                return false;
            }
        }
    }
     // Create a function that will receive data 
     // sent from the server and will update
     // div section in the same page.
    ajaxRequest.onreadystatechange = function() {
        if(ajaxRequest.readyState == 4) {
            document.getElementById("groupViewDiv").innerHTML=ajaxRequest.responseText;
        }
    }
     // Now get the value from user and pass it to
    // server script.
   //var course = "?course_id=" + courseid;
    var user="?user_id="+userid;
    var course="&course_id="+courseid;
    var query=user+course;

    ajaxRequest.open("GET",root+"/blocks/group_view/response_groups.php" + query, true);
    ajaxRequest.send(null);      
}

function genGroups(userid, root, courseDivId, courseid) {    
    //Make the userViewDiv blank as soon as new course is selected
    document.getElementById("userViewDiv").innerHTML="";

    //Make the course that is selected bold using jquery
    var jqCourseString="#"+courseDivId;
    $(jqCourseString).css({'font-weight':'bold'});

    //Also make the other children normal( which are not having this id) using jquery
    $('#courseViewDiv > *:not('+jqCourseString+')').css({'font-weight':'normal'});
    getGroupsAjaxFunction(userid,root, courseid);    
}

function getUsersAjaxFunction(userid, root, groupid) { 
    var ajaxRequest;// The variable that makes Ajax possible!
    try {
        //Opera 8.0+, Firefox, Safari
        ajaxRequest = new XMLHttpRequest();
    }
    catch (e) {
       // Internet Explorer Browsers
        try {
            ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (e) {
            try {
                ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (e) {
             // Something went wrong
                alert("Your browser broke!");
                return false;
            }
        }
    }
     // Create a function that will receive data 
     // sent from the server and will update
     // div section in the same page.
    ajaxRequest.onreadystatechange = function() {
        if(ajaxRequest.readyState == 4) {
            document.getElementById("userViewDiv").innerHTML=ajaxRequest.responseText;
        }
    }
     // Now get the value from user and pass it to
     // server script.
    var user = "?user_id=" + userid;
    var group = "&group_id=" + groupid;
    var query = user+group;
    //Ajax request
    ajaxRequest.open("GET",root+"/blocks/group_view/response_users.php" + query, true);
    ajaxRequest.send(null);    
}

function showUsers(userid,root,groupid,groupDivId) {
    //Make the clicked group bold 
    var jqGroupString="#"+groupDivId;
    $(jqGroupString).css({'font-weight':'bold'}); 
    //Also make the other children normal( which are not having this id)
    $('#groupViewDiv > *:not('+jqGroupString+')').css({'font-weight':'normal'});  
    //fill up the userViewDiv with users lastname,firstname
    getUsersAjaxFunction(userid,root,groupid);
}

