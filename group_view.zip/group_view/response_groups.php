<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once('../../config.php');

global $DB,$CFG;
$root = $CFG->wwwroot;

$userid=$_GET['user_id'];
$courseid = $_GET['course_id'];

$groups = $DB->get_records_sql('
    SELECT mgm.groupid as groupid, mg.name as groupname
    FROM   mdl_groups_members mgm, mdl_groups mg, mdl_course mc
    WHERE  userid=?
    AND    mgm.groupid=mg.id
    AND    mg.courseid=mc.id
    AND    mc.id=?
    ORDER BY groupname ASC', array($userid,$courseid));

foreach ($groups as $group) {
    $group_id=$group->groupid;
    $string="groupDiv";
    $groupDivId=$string.$group_id;
    
    $display_string .= 
        '<div id= '.$groupDivId.'>
              <a href="javascript:void(0)" onclick="showUsers('.$userid.', \''.$root.'\', \''.$group_id.'\', \''.$groupDivId.'\')">'.$group->groupname.'</a> 
         </div>';
}

echo $display_string;


