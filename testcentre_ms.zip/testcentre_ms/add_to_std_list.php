<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
global $DB, $USER;

$username = $_POST['username'];
$exam_id = $_POST['exam_id'];
$id_type = $_POST['id_type'];
$machine_no = $_POST['machine_no'];
$comments = $_POST['comments'];

$std_is_in_record = $DB->get_record('local_testcentre_std_entry',array('username' =>$username , 'examid'=> $exam_id));
$username_record = $DB->get_record('user',array('username' => $username));
$examname_record = $DB->get_record('quiz',array('id' => $exam_id));
$coursename_record = $DB->get_record('course', array('id' => $examname_record->course));

if(!$std_is_in_record) {
    //insert a row
    $record = new stdClass();
    $record->username = $username;
    $record->examid = $exam_id;
    $record->machine_no = $machine_no;
    $record->time_signed = time();
    $record->id_type = $id_type;

    $inserted_id = $DB->insert_record('local_testcentre_std_entry', $record, true);

    //Grab the inserted record and send to the calling ajax function
    //$exam_record = $DB->get_record('local_testcentre_useradmin',array('id'=> $inserted_id));
    $row = array('id' => $inserted_id,
                 'username' => $username_record->username, 
                 'examname' => $coursename_record->fullname.'-'.$examname_record->name, 
                 'machine_no' => $machine_no,
                 'timesigned' => date('Y-m-d H:i:s',$record->time_signed),
                 'comments' => $comments
           );   
    echo json_encode($row);   
}
else {
    echo json_encode(array('Error Message 1' => 'This exam is already in the record'));
}   

?>
