<?php
/**
 * ************************************************************************
 * *                             Testcentre_ManagementSystem             **
 * ************************************************************************
 * @package     local                                                    **
 * @subpackage  testcentre_ms                                            **
 * @name        testcentre_ms                                            **                                                                       **                                                                       **
 * @author      Nawshad Farruque           				 **
 *                                                                       **
 * ************************************************************************
 * ************************************************************************/

defined('MOODLE_INTERNAL') || die();

$capabilities = array(
        'local/testcentre_ms:admin' => array(
        'captype' => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes' => array(
            'user' => CAP_PREVENT,
            'guest' => CAP_PREVENT,
            'student' => CAP_PREVENT,
            'teacher' => CAP_PREVENT,
            'editingteacher' => CAP_PREVENT,
            'manager' => CAP_ALLOW
        )
        
    )

);

