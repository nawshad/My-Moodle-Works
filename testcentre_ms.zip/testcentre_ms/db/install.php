<?php
/**
 * ************************************************************************
 * *                Test Centre Management System                        **
 * ************************************************************************
 * @package     Test Centre Management System                            **  
 * @name        Test Centre Management System                            **
 * @author      Nawshad Farruque                                         **
 * ************************************************************************
 * ********************************************************************** */


/**
 * Post installation procedure
 */
//require_once('../local/evaluations/locallib.php');
/*function xmldb_testcentre_ms_install() {

    //global $DB;
    
    //return true;
    //update_question_types();
    //role_install(); 
}*/
