/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function(){   
    function checkboxValues() {         
        var allVals = [];
        $(':checkbox:checked').each(function() {
          allVals.push($(this).val());
        });
        return allVals; // process the array as you wish in the function so it returns what you need serverside
    }    
})
