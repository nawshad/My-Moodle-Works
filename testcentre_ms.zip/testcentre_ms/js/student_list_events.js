/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function(){
    $('#id_tc_std_list_useridno').focus();
    //$('#id_tc_std_list_useridno').attr( "autocomplete", "off" );
    $( "#id_tc_std_list_useridno" ).keypress(function (e) {
       //console.log(this.value.length);   
        if (e.keyCode == 13) {
            e.preventDefault();
            //return false;
        }
       
       if(this.value.length==11){
           //console.log('Gotcha');
           process_ID(this.value);
           return true;
       }
    })
    
    function process_ID(id_no){
        var actual_id = id_no.match("[%](.*)[?]")[1];    
        $.ajax({
            type: "POST",
            url: 'load_std_info.php',
            data: {uoflid:  actual_id},
            success:function(evt){
                var std_id = $.parseJSON(evt); 
                console.log(std_id);
            }
        })
    }  
    
    $.ajax({
        type: "POST",
        url: 'load_users.php',
        success:function(evt){
            var availableTags = $.parseJSON(evt); 
            $("#id_tc_std_list_username").autocomplete({
                source: availableTags,
                minLength: 3
            });
        },
        error:function(evt){
            console.log("FAIL: What is evt: ");
            console.log(evt);
        } 
    }) 
    
    //loading all those courses where the user is enrolled to
    var error = 0;
    $("#id_tc_std_list_username").focusout(
        function(){
            console.log(this.value); 
            $.ajax({
                type: "POST",
                url: 'load_user_exams.php',
                data: {username:  $('#id_tc_std_list_username').val()},
                cache: false,
                success:function(evt){
                    var courses = $.parseJSON(evt); 
                    console.log(courses['label']);
                    if(courses['label']=='null'){
                        alert('This user has no test centre exams!');
                        error = 1; 
                    }
                    else{
                        $("#id_tc_std_list_exams").autocomplete({
                            source: courses,
                            minLength: 1
                        }); 
                    }
                },
                error:function(evt){
                    console.log("FAIL: What is evt: ");
                    console.log(evt);
                } 
            })
        }
    );
    
    //Table initializations
    var oTable = $('#tcStdList').dataTable({      
       "aoColumns": [ 
          {"bVisible": false},
           null,
           null,
           null,
           { "sClass": "editable"},
           null,
           { "sClass": "editable"},
        ],
        "bInfo": true,
        "sScrollY": "200px"
    }).makeEditable(/*{sDeleteURL: "delete_std.php"}*/);
        
    $('td.editable').editable( 'update_std_list.php', {
        "type"  : "textarea",
        "submitdata": function ( value, settings ) {
             return {
                 "row_id": this.parentNode.getAttribute('id'),
                 "column": oTable.fnGetPosition( this )[2]
             };
        },
        "onblur": 'submit'
    });
    
    function add_to_std_list_table(){
        /*var query_data = '';
        var url_string = '';

        if(from_record==0){*/
        query_data = {'username': $('#id_tc_std_list_username').val(), 'exam_id':  $("#id_tc_std_list_exams").val(), 'id_type': $('#id_tc_std_list_selectid').val(), 'machine_no': $('#id_tc_std_list_machineno').val(), 'comments': $('#id_tc_std_list_comments').val()};
        url_string = 'add_to_std_list.php';
        /*}
        else{
            query_data = {'course_id': $('#tc_courseid').val(), 'exam_id': $('#tc_examid').val()};
            url_string = 'open_exams.php';

        }*/
        //console.log("Save button pressed!"); 
        $.ajax({
            url: url_string,
            data: query_data, 
            type: 'POST',
            success: function(evt) {
                console.log("SUCCESS: What is evt: ");
                var std_list_record = '';
                std_list_record = $.parseJSON(evt);
                //console.log(std_list_record);
                if(std_list_record['Error Message 1']){
                    alert(std_list_record['Error Message 1']);
                }
                else{
                  var checkboxElement = '';
                  checkboxElement = '<input type= checkbox name = std_list_selectCheckBox  value = '+std_list_record['id']+' id = '+std_list_record['id']+'>'; 
                  //console.log(std_list_record);
                  var row_data = new Array();
                  row_data = [  std_list_record['id'],
                                checkboxElement,
                                std_list_record['username'],
                                std_list_record['examname'],
                                std_list_record['machine_no'],
                                std_list_record['timesigned'],
                                std_list_record['comments']
                             ];
                  console.log(row_data);
                  $('#tcStdList').dataTable().fnAddData(row_data); 
                  //this chunk of code is for adding jeditable functionality for added row.
                  $('td.editable').editable( 'update_std_list.php', {
                      "type"      : "textarea",
                      "submitdata": function ( value, settings ) {
                           return {
                               "row_id": this.parentNode.getAttribute('id'),
                               "column": oTable.fnGetPosition( this )[2]
                           };
                      },
                      "onblur": 'submit'
                  });
                }   
            },
            error: function(evt){
                console.log(evt);
            }
        });
        return false;
    }
    
    //defining what would happen if save in std_list form clicked
    $('#id_tc_std_list_open_std').click(function(e){
        console.log('Open Button Clicked');
        var username = $.trim($("#id_tc_std_list_username").val());
        var examname = $.trim($("#id_tc_std_list_exams").val());
        if(!examname.length>0 || !username.length>0){
            alert('Please fill in both coursename and username');
        }
        else{
            if(!error){
                add_to_std_list_table(); 
            }
            else{
                alert('Exam doesnt exist!');
            }
        }
    })
    
    function checkboxValues() {         
        var allVals = [];
        $(':checkbox:checked').each(function() {
            allVals.push($(this).val());
        });
        return allVals; // process the array as you wish in the function so it returns what you need serverside
    }  
    //Define the delete button
    $('#id_tc_close_std').click(function(e) {
        //find out all the input ids that are clicked, delete those from the page, from the table cache and send to delete script
        var checkboxValuesArray = new Array();
        checkboxValuesArray = checkboxValues();
        for(var i=0; i<checkboxValuesArray.length; i++) {
            var id =  checkboxValuesArray[i];
            console.log();
            var oTable = $('#tcStdList').dataTable();
            oTable.fnDeleteRow(oTable.fnGetPosition(document.getElementById(id)));
        }
            
        $.ajax({
            url: 'delete_stds.php',
            data:{'checkboxVals': checkboxValuesArray},
            type: 'POST',
            success: function(evt) {
                console.log("SUCCESS: What is evt: ");
                console.log(evt);         
            },
            error: function(evt){
                console.log(evt);
            }
        });
        return false;
    }) 
      
})
