/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function(){
    var oTable = $('#tcExamList').dataTable({      
       "aoColumns": [ 
          {"bVisible": false},
           null,
           null,
           null,
           null,
           null,
           { "sClass": "editable"},
           { "sClass": "editable"/*,"type" : "textarea"*/}
        ],
        "bInfo": true
    }).makeEditable(/*{ sDeleteURL: "delete_exams.php"}*/);
        
    $('td.editable').editable( 'update_exams.php', {
        "type"      : "textarea",
        "submitdata": function ( value, settings ) {
            return {
                "row_id": this.parentNode.getAttribute('id'),
                "column": oTable.fnGetPosition( this )[2]
            };
        },
        "onblur": 'submit'
    });
    
    var add_exam_popup = 
        '<div class = "white-popup custom-white-popup">\n\
            <div id = exam_form>\n\
                Course Name: <div id = course_name_input class = allign ><input id = id_tc_coursename type = text></div>\n\
                Exam Name: <div id = exam_name_input class = allign><input id = id_tc_examname type = text></div> \n\
                Password: <div id = password_input class = allign><input id = id_tc_pass type = text></div> \n\
                Notes: <div id = notes_input class = allign><textarea id = exam_notes_txtarea></textarea></div> \n\
                <div id = "saveExamButtonID" class = buttonDivAllign><button id = "saveExamButton" class = "buttonClass">Save</button></div>\n\
             </div>\n\
         </div>';
    
    var open_exam_popup =  
        '<div class = "white-popup custom-white-popup">\n\
            <div id = exam_form>\n\
                Course Name: <div id = course_name_input class = allign ><input id = id_tc_coursename type = text></div>\n\
                Exam Name: <div id = exam_name_input class = allign><input id = id_tc_examname type = text></div> \n\
                <div id = "openExamButtonID" class = buttonDivAllign><button id = "openExamButton" class = "buttonClass">Open</button></div>\n\
            </div>\n\
         </div>';
       
    function showModal(modal_type){
        console.log("Modal has been opened........");
        $.magnificPopup.open({
            items: {
                src: modal_type, 
                type: 'inline'
            },
        closeOnContentClick: false,
        showCloseBtn: true
     });

     var operation_type;
     if(modal_type ==add_exam_popup){
        operation_type = {op: "load_all_exams"};
     }
     else{
        operation_type = {op: "load_only_unopened_exams"};
     }

     //Commented code was the implementation of using key for both showing and putting it in the input box,
     //it used to save courseid in another hidden field bypassing the autocompletes
     //own capability of showing key but putting the value for it.
    /*$("#id_tc_coursename").autocomplete({
        //dataType: "json",
        autoFocus: true,
        type: "POST",
        //contentType: "application/json; charset=utf-8",
        //source: 'load_courses.php',
        //data: operation_type,
        //dataType: "json",
        //minLength: 2,
        source: function (request, response) {
            return $.ajax({
                type: "POST",
                //contentType: "application/json; charset=utf-8",
                url: 'load_courses.php',
                data: operation_type,
                dataType: "json",
                success: function (data) {
                    response($.map(data, function (c) {
                        return {
                            label: c.label,
                            value: c.value
                        };
                    }));
                    //console.log(data);
                }
            });
        },
        select: function (event, ui) {
            var lbl = ui.item.label;
            var val = ui.item.value;
            $('#id_tc_coursename').html(lbl);
            $('#tc_courseid').val(val); 
            this.value = lbl; 
            return false;
         }
    })*/

        $.ajax({
            type: "POST",
            url: 'load_courses.php',
            data: {op: operation_type['op']},
            success:function(evt){
                var courses = $.parseJSON(evt); 
                console.log(evt);
                $("#id_tc_coursename").autocomplete({
                    source: courses,
                });
            },
            error:function(evt){
                console.log("FAIL: What is evt: ");
                console.log(evt);
            }
        })

        $("#id_tc_coursename").focusout(
            function(){
                console.log(this.value); 
                $.ajax({
                    type: "POST",
                    url: 'load_exams.php',
                    data: {courseid:  $('#id_tc_coursename').val(), op: operation_type['op']},
                    success:function(evt){
                        var exams = $.parseJSON(evt); 
                        console.log(evt);
                        $("#id_tc_examname").autocomplete({
                            source: exams,
                            /*select: function (event, ui) {
                               var lbl = ui.item.label;
                               var val = ui.item.value;
                               $('#id_tc_examname').html(lbl);
                               $('#tc_examid').val(val);
                               // update what is displayed in the textbox
                               this.value = lbl; 
                               return false;
                            }*/
                        });
                    },
                    error:function(evt){
                        console.log("FAIL: What is evt: ");
                        console.log(evt);
                    } 
               })
         });

        //defining what would happen if save in exam form clicked
        $('#saveExamButton').click(function(e){
            var from_record = 0;
            console.log('Exam Save Button Clicked');
            var coursename = $.trim($("#id_tc_coursename").val());
            var examname = $.trim($("#id_tc_examname").val());
            if(!coursename.length>0 || !examname.length>0){
                alert('Please fill in both coursename and examname');
            }
            else{
                add_to_table(from_record);
            }
        }) 

        //defining what would happen if save in open exam form clicked
        $('#openExamButton').click(function(e) {
            var from_record = 1;
            console.log('Open Exam Save Button Clicked');
            var coursename = $.trim($("#id_tc_coursename").val());
            var examname = $.trim($("#id_tc_examname").val());
            //validation check
            if(!coursename.length>0 || !examname.length>0){
                alert('Please fill in both course name and exam name');
            }
            else{
                add_to_table(from_record);
            }
        }) 
    } 
     
    //reused the following fucntion for both opening record and adding record in test_centre_exam_pass table
    function add_to_table(from_record){
        var query_data = '';
        var url_string = '';

        if(from_record==0){
            query_data = {'course_id': $('#id_tc_coursename').val(), 'exam_id': $('#id_tc_examname').val(), 'password': $('#id_tc_pass').val(), 'notes': $('#exam_notes_txtarea').val()};
            url_string = 'add_exams.php';
        }
        else{
            query_data = {'course_id': $('#id_tc_coursename').val(), 'exam_id': $('#id_tc_examname').val()};
            url_string = 'open_exams.php';

        }
        //console.log("Save button pressed!"); 
        $.ajax({
            url: url_string,
            data: query_data, 
            type: 'POST',
            success: function(evt) {
               console.log("SUCCESS: What is evt: ");
               var exam_record = '';
               exam_record = $.parseJSON(evt);
               if(exam_record['Error Message 1']){
                   alert(exam_record['Error Message 1']);
               }
               else{
                 var checkboxElement = '';
                 checkboxElement = '<input type= checkbox name = tc_pass_exam_selectCheckBox  value = '+exam_record['id']+' id = '+exam_record['id']+'>'; 
                 console.log(exam_record);
                 var row_data = new Array();
                 row_data = [  exam_record['id'],
                              checkboxElement,
                              exam_record['coursename'],
                              exam_record['examname'],
                              exam_record['openingdate'],
                              exam_record['closingdate'],
                              exam_record['password'],
                              exam_record['notes']
                           ];
                 console.log(row_data);
                 $('#tcExamList').dataTable().fnAddData(row_data); 
                //this chunk of code is for adding jeditable functionality for added row.
                 $('td.editable').editable( 'update_exams.php', {
                     "type"      : "textarea",
                     "submitdata": function ( value, settings ) {
                          return {
                              "row_id": this.parentNode.getAttribute('id'),
                              "column": oTable.fnGetPosition( this )[2]
                          };
                     },
                     "onblur": 'submit'
                 });
               }   
            },
            error: function(evt){
                console.log(evt);
            }
        });
        return false;
    }
    
    function checkboxValues() {         
        var allVals = [];
        $(':checkbox:checked').each(function() {
            allVals.push($(this).val());
        });
        return allVals; // process the array as you wish in the function so it returns what you need serverside
    }  
    //Define the delete button
    $('#id_tc_close_exam').click(function(e) {
        //find out all the input ids that are clicked, delete those from the page, from the table cache and send to delete script
        var checkboxValuesArray = new Array();
        checkboxValuesArray = checkboxValues();
        for(var i=0; i<checkboxValuesArray.length; i++) {
            var id =  checkboxValuesArray[i];
            console.log();
            var oTable = $('#tcExamList').dataTable();
            oTable.fnDeleteRow(oTable.fnGetPosition(document.getElementById(id)));
        }

        $.ajax({
            url: 'delete_exams.php',
            data:{'checkboxVals': checkboxValuesArray},
            type: 'POST',
            success: function(evt) {
                console.log("SUCCESS: What is evt: ");
                console.log(evt);         
            },
            error: function(evt){
                console.log(evt);
            }
        });
        return false;
    }) 

    $('#btnAddNewRow').click(function(e){  
        showModal(add_exam_popup);   
    })

    $('#btnOpenRow').click(function(e){  
        showModal(open_exam_popup);   
    })
})
