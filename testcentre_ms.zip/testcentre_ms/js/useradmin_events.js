
$(document).ready(function(){  
    /*
     * print the list of the currently stored selected lists to the php console
    */
   //enable datatable
   /* $('#tcUserList').dataTable({
        /*"bProcessing": true,
        "bServerSide": true,    
    });*/
    
    var oTable = $('#tcUserList').dataTable({      
       "aoColumns": [ 
          {"bVisible": false},
           null,
           null,
           null,
           null
        ],
        "bInfo": false,
        "bPaginate": true,
        "bLengthChange": true,
        "bFilter": true,
        "bSort": true,
        "bInfo": true,
        "bAutoWidth": false,
        "sScrollY": "400px"
    }).makeEditable();
    
    
    //load the username dropdownbox
    $.ajax({
        type: "POST",
        url: 'load_users.php',
        success:function(evt){
            var availableTags = $.parseJSON(evt); 
            //console.log(availableTags);
            $("#id_tc_username").autocomplete({
                source: availableTags,
                minLength: 3
            });
        },
        error:function(evt){
            console.log("FAIL: What is evt: ");
            console.log(evt);
        } 
    })   
    //Update that table with new records everytime the button is clicked    
    $('#id_tc_add_user').click(function(e) {
        console.log("Add user button pressed!"); 
        $.ajax({
            url: 'add_users.php',
            data:{'username': $('#id_tc_username').val(), 'access_level': $('#id_tc_selectrole').val()},
            type: 'POST',
            success: function(evt) {
                console.log("SUCCESS: What is evt: ");
                var user_record = '';
                user_record = $.parseJSON(evt);
                if(user_record['Error Message 1']){
                    alert(user_record['Error Message 1']);
                }
                else if(user_record['Error Message 2']){
                    alert(user_record['Error Message 2'])
                }
                else{
                    console.log(user_record);
                    var checkboxElement = '';
                    checkboxElement = '<input type= checkbox name = selectCheckBox  value = '+user_record['id']+' id = '+user_record['id']+'>';
                    var row_data = new Array();
                    //row_data.length = 0;
                    row_data = [ user_record['id'],
                                 checkboxElement,
                                 user_record['name'],
                                 user_record['username'],
                                 user_record['access_level']];
                    console.log(row_data);
                    $('#tcUserList').dataTable().fnAddData(row_data);
                   //$('#tcUserList tr:last').attr('id',user_record['id']);              
                }   
            },
            error: function(evt){
                console.log(evt);
            }
        });
        return false;
    })
    
    function checkboxValues() {         
        var allVals = [];
        $(':checkbox:checked').each(function() {
          allVals.push($(this).val());
        });
        return allVals; // process the array as you wish in the function so it returns what you need serverside
    }  
    //Define the delete button
    $('#id_tc_delete_user').click(function(e) {
        //find out all the input ids that are clicked, delete those from the page, from the table cache and send to delete script
        var checkboxValuesArray = new Array();
        checkboxValuesArray = checkboxValues();
        for(var i=0; i<checkboxValuesArray.length; i++) {
            var id =  checkboxValuesArray[i];
            console.log();
            //$('#tcUserList').dataTable().fnDeleteRow($("#child-"+id).index());
            //var aPos = $('#tcUserList').dataTable().fnGetPosition('tr');
            //console.log(aPos);
            //$('#child-'+id).remove(); 
            var oTable = $('#tcUserList').dataTable();
            oTable.fnDeleteRow(oTable.fnGetPosition(document.getElementById(id)));
        }
            
        $.ajax({
            url: 'delete_users.php',
            data:{'checkboxVals': checkboxValuesArray},
            type: 'POST',
            success: function(evt) {
               console.log("SUCCESS: What is evt: ");
               console.log(evt);         
            },
            error: function(evt){
              console.log(evt);
            }
        });
        return false;
    })
});
