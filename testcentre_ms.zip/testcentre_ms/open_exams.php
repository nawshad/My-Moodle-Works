<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
global $DB, $USER;

$courseid = $_POST['course_id'];
$examid = $_POST['exam_id'];

$get_exam_record = $DB->get_record('local_testcentre_exam_pass',array('courseid' => $courseid, 'examid' => $examid));
$get_quiz_record = $DB->get_record('quiz',array('id' => $examid));
$get_course_record = $DB->get_record('course',array('id' => $courseid));

$record_update = new stdClass();
$record_update->id = $get_exam_record->id;
$record_update->deleted = 0;

$DB->update_record('local_testcentre_exam_pass', $record_update, false);

if($get_quiz_record->timeopen>0 && $get_quiz_record->timeclose>0){
    $opening_date = date('Y-m-d H:i:s',$get_quiz_record->timeopen);
    $closing_date = date('Y-m-d H:i:s',$get_quiz_record->timeclose);
    //$mform->addElement(html,"<tr id = $get_exam_info->id ><td>$get_exam_info->id</td><td><input type= 'checkbox' name = 'tc_exam_pass_selectCheckBox' value = $get_exam_info->id></td><td>$get_exam_info->coursename</td><td>$get_exam_info->examname</td><td>$opening_date</td><td>$closing_date</td><td>$get_exam_info->password</td><td>$get_exam_info->notes</td></tr>") ;                 
} 
else{
    $opening_date = 'Not Yet Set';
    $closing_date = 'Not Yet Set';
}

$row = array('id' => $get_exam_record->id,
             'coursename' => $get_course_record->fullname, 
             'examname' => $get_quiz_record->name,
             'openingdate' => $opening_date,//date('Y-m-d H:i:s', $get_quiz_record->timeopen),
             'closingdate' => $closing_date,//date('Y-m-d H:i:s', $get_quiz_record->timeclose),
             'password' => $get_exam_record->password,
             'notes' => $get_exam_record->notes
       );   

echo json_encode($row);   
 
?>