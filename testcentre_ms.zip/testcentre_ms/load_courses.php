<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
//require_once('ldap.php');
global $DB, $USER;
$operation = $_POST['op'];
//query out all the users and send their lastname,firstname and uleth username
if($operation == 'load_only_unopened_exams'){
   // echo 'load_only_unopened_exam';
    $get_courses = $DB->get_records_sql('
                       SELECT distinct mc.id, mc.fullname
                       FROM mdl_course mc, mdl_quiz mq, mdl_local_testcentre_exam_pass ltep
                       WHERE mc.id = mq.course
                       AND mc.id = ltep.courseid
                       AND ltep.deleted=1');    
}
else{
    $get_courses = $DB->get_records_sql('
                       SELECT distinct mc.id, mc.fullname
                       FROM mdl_course mc, mdl_quiz mq
                       WHERE mc.id = mq.course
                       ORDER BY mc.fullname ASC');  
}

$i=0;
foreach($get_courses as $get_course){
    $rows[$i++] = array('label' => $get_course->fullname, 'value' =>$get_course->id);   
}
echo json_encode($rows);


?>
