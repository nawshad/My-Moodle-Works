<?php
/**
 * ************************************************************************
 * *                   Test Centre Management System                     **
 * ************************************************************************
 * @package Test Centre Management System                                **
 * @author Nawshad Farruque                                              **
 * ************************************************************************/
//strings for index.php file
$string['pluginname'] = 'Test Centre Management System';
$string['plugins'] = 'Plugins';
$string['nav_tc_mn'] = 'Test Centre Management System';

//strings for useradmin_form
$string['nav_tc_admin'] = 'User Administration';
$string['username'] = 'UofL username:';
$string['selectrole'] = 'Select a role:';
$string['add_user'] = 'Add User';
$string['delete_user'] = 'Delete Selected';
//strings for useradmin_form table
$string['id_header'] = 'id';
$string['select_header'] = 'Select';
$string['name_header'] = 'Name';
$string['username_header'] = 'Username';
$string['access_level_header'] = 'Access Level';

//strings for tc_pass_admin_form
$string['nav_tc_pass_admin'] = 'Exam Pass Administration';
$string['coursename'] = 'Course:';
$string['examname'] = 'Exam:';
$string['openingdate'] = 'Opening Date(yyyy-mm-dd 10:00):';
$string['closingdate'] = 'Closing Date(yyyy-mm-dd 22:00):';
$string['examname'] = 'Exam:';
$string['password'] = 'Password:';
$string['notes'] = 'Notes:';
$string['delete_record'] = 'Delete';
$string['add_exam'] = 'Add Exam';
$string['add_record'] = 'Add record';
$string['close_exam'] = 'Close record';
$string['open_exam'] = 'Open record';
//tc_pass_admin_form table
$string['course_header'] = 'Course';
$string['exam_pass_id_header'] = 'Course id';
$string['exam_header'] = 'Exam';
$string['openingdate_header'] = 'Opening Date';
$string['closingdate_header'] = 'Closing Date';
$string['password_header'] = 'Password';
$string['notes_header'] = 'Notes';

//strings for student_list_form
$string['nav_tc_std_list'] = 'Student list';
$string['std_list_username'] = 'Username:';
$string['std_list_useridno'] = 'UofL ID #:';
$string['std_list_exams'] = 'Exams:';
$string['std_list_selectid'] = 'ID Type:';
$string['std_list_machineno'] = 'Machine #:';
$string['std_list_comments'] = 'Comments:';
$string['std_list_open_std'] = 'Open Student';
$string['std_list_image'] = 'Student Image';
$string['std_list_close_record'] = 'Close selected record';
//strings for student_list_form table
$string['std_list_id_header'] = 'id';
$string['std_list_username_header'] = 'Username';
$string['std_list_course_header'] = 'Course';
$string['std_list_machine_header'] = 'Machine #';
$string['std_list_signedup_header'] = 'Time Signed in';
$string['std_list_comments_header'] = 'Comments';

?>


