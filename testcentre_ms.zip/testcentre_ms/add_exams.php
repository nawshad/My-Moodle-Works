<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
global $DB, $USER;

$courseid = $_POST['course_id'];
$examid = $_POST['exam_id'];
$password = $_POST['password'];
$notes = $_POST['notes'];


$exam_is_in_record = $DB->get_record('local_testcentre_exam_pass',array('examid'=> $examid));
$coursename = $DB->get_record('course',array('id' => $courseid));
$examname = $DB->get_record('quiz',array('id' => $examid));
//$opening_date = date('Y-m-d H:i:s',$examname->timeopen);
//$closing_date = date('Y-m-d H:i:s',$examname->timeclose);

if($examname->timeopen>0 && $examname->timeclose>0){
    $opening_date = date('Y-m-d H:i:s',$examname->timeopen);
    $closing_date = date('Y-m-d H:i:s',$examname->timeclose);
    //$mform->addElement(html,"<tr id = $get_exam_info->id ><td>$get_exam_info->id</td><td><input type= 'checkbox' name = 'tc_exam_pass_selectCheckBox' value = $get_exam_info->id></td><td>$get_exam_info->coursename</td><td>$get_exam_info->examname</td><td>$opening_date</td><td>$closing_date</td><td>$get_exam_info->password</td><td>$get_exam_info->notes</td></tr>") ;                 
} 
else{
    $opening_date = 'Not Yet Set';
    $closing_date = 'Not Yet Set';
}

if(!$exam_is_in_record) {
    //insert a row
    $record = new stdClass();
    $record->courseid = $courseid;
    //$record->coursename = $coursename->fullname;
    $record->examid = $examid;
    //$record->examname = $examname->name;
    //$record->opening_date =  $examname->opening_date;
    //$record->closing_date = $examname->closing_date;
    $record->password = $password;
    $record->notes = $notes;

    $inserted_id = $DB->insert_record('local_testcentre_exam_pass', $record, true);

    //Grab the inserted record and send to the calling ajax function
    //$exam_record = $DB->get_record('local_testcentre_useradmin',array('id'=> $inserted_id));
    $row = array('id' => $inserted_id,
                 'coursename' => $coursename->fullname, 
                 'examname' => $examname->name,
                 'openingdate' => $opening_date,
                 'closingdate' => $closing_date,
                 'password' => $password,
                 'notes' => $notes
           );   
    echo json_encode($row);   
}
else {
    echo json_encode(array('Error Message 1' => 'This exam is already in the record'));
}   


?>
