<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');

global $DB, $USER;
$username = $_POST["username"];

$get_user_courses = $DB->get_records_sql('
                                SELECT  mq.id as id, fullname||\'-\'||mq.name as examname
                                FROM mdl_course mc, mdl_user mu,mdl_enrol me,mdl_user_enrolments mue, mdl_quiz mq
                                WHERE mu.username = ? 
                                AND mu.id = mue.userid
                                AND mue.enrolid = me.id
                                AND me.courseid = mc.id
                                AND mq.course = mc.id',array($username));



if($get_user_courses == null){
    echo json_encode(array('label' => 'null'));
}
else{
    $i=0;
    foreach($get_user_courses as $get_user_course){
        $rows[$i++] = array('label' => $get_user_course->examname, 
                            'value' =>$get_user_course->id);   
        }
    echo json_encode($rows);
}



?>
