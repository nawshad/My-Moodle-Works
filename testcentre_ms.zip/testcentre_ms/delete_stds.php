<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
//require_once('ldap.php');
global $DB, $USER;
//query out all the users and send their lastname,firstname and uleth username
$stds_to_be_deleted = $_POST['checkboxVals'];
$record_update = new stdClass();
foreach($stds_to_be_deleted as $stdid){
    $record_update->id = $stdid;
    $record_update->deleted = 1;
    $DB->update_record('local_testcentre_std_entry', $record_update, false);   
}
echo 'successfully closed';
?>
