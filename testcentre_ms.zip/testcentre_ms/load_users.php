<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
//require_once('ldap.php');
global $DB, $USER;
//query out all the users and send their lastname,firstname and uleth username
$get_users = $DB->get_records_sql('
                 SELECT id, username, lastname||\',\'||firstname as name 
                 FROM mdl_user'
              );
//echo 'successful';
$i=0;
foreach($get_users as $get_user)
{
    $rows[$i++] = array('label' => $get_user->name, 
                        'value' =>$get_user->username);   
}
echo json_encode($rows);
?>

