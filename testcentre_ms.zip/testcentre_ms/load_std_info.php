<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

define("CLI_SCRIPT",true);
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
global $DB, $USER;

$uoflid = $_POST['uoflid'];

$dbHost = "oradd.uleth.ca";
$dbHostPort="1521";
$dbServiceName = "dd.cc.uleth.ca";
$usr = "moodleimagetest";
$pswd = "moodletemp1!";
$dbConnStr = "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)
            (HOST=".$dbHost.")(PORT=".$dbHostPort."))
            (CONNECT_DATA=(SERVICE_NAME=".$dbServiceName.")))";


if(!$dbConn = oci_connect($usr,$pswd,$dbConnStr)){
    $err = oci_error();
    //trigger_error('Could not establish a connection: ' . $err['message'], E_USER_ERROR);
};

echo json_encode($uoflid);

?>
