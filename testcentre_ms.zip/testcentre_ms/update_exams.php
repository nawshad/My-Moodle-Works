<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
//require_once('ldap.php');
global $DB, $USER;

$editedid = $_POST['row_id'];
$editedValue = $_POST['value'];
$columnindex = $_POST['column'];

//do update in database

$record_update = new stdClass();
$record_update->id = $editedid;

if($columnindex==6){  
    $record_update->password = $editedValue;
    $DB->update_record('local_testcentre_exam_pass', $record_update, false);
    echo $editedValue;
}
else if($columnindex==7){
    $record_update->notes = $editedValue;
    $DB->update_record('local_testcentre_exam_pass', $record_update, false);
    echo $editedValue;
}

?>
