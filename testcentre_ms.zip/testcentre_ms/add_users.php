<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
//require_once('ldap.php');
global $DB, $USER;
//query out all the users and send their lastname,firstname and uleth username
$username = $_POST['username']; 
$access_level = $_POST['access_level'];
//find if this username really exists or not
$user_exist = $DB->get_record('user',array('username'=> $username));
if($user_exist) {
    //check if this user is already in the record
    $user_is_in_record = $DB->get_record('local_testcentre_useradmin',array('username'=> $username));
    if(!$user_is_in_record) {
        //insert a row
        $record = new stdClass();
        $record->userid = $user_exist->id;
        $record->name         =  $user_exist->lastname.','.$user_exist->firstname;
        $record->username = $user_exist->username;
        $record->access_level = $access_level;
        $inserted_id = $DB->insert_record('local_testcentre_useradmin', $record, true);
        
        //Grab the inserted record and send to the calling ajax function
        $user_record = $DB->get_record('local_testcentre_useradmin',array('id'=> $inserted_id));
        $row = array('id' => $inserted_id,
                     'userid'=> $user_record->userid,
                     'name' => $user_record->name, 
                     'username' => $user_record->username,
                     'access_level' => $user_record->access_level
               );   
        echo json_encode($row);   
    }
    else {
        echo json_encode(array('Error Message 1' => 'User is already assigned a role!'));
    }   
}
else{
    echo json_encode(array('Error Message 2' => 'There is no such user!'));
}

?>
