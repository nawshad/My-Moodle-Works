<?php

/**
 * ************************************************************************
 * *                  Testcentre Management System                       **
 * ************************************************************************
 * /**
 * @package     local                                                    **
 * @subpackage  Testcentre Management                                    **
 * @name        Testcentre Management                                    **
 * @author      Nawhsad Farruque                                         **
 *                                                                       **
 * ************************************************************************
 * ********************************************************************** */
/**
 * This is the main entry point for the evaluations plugin. It is a menu screen
 * that you will see when you first access the plugin.
 */
require_once(dirname(dirname(dirname(__FILE__))). '/config.php');
global $DB, $USER;
//require_once('locallib.php');
$context = get_context_instance(CONTEXT_SYSTEM);
$PAGE->set_context($context);
$navlinks = array(
    array(
        'name' => get_string('nav_tc_mn', 'local_testcentre_ms'),
        'link' => '',
        'type' => 'misc'
    ),
);
$nav = build_navigation($navlinks);

//Set page headers.
$PAGE->set_title(get_string('nav_tc_mn', 'local_testcentre_ms'));
$PAGE->set_heading(get_string('nav_tc_mn', 'local_testcentre_ms'));
$PAGE->requires->css('/local/testcentre_ms/style.css');
$PAGE->set_pagelayout('standard');
require_login();

echo $OUTPUT->header();

//checking previlidge to go for assigning users different levels
$admins = get_admins();
$isadmin = false;
foreach ($admins as $admin) {
    if ($USER->id == $admin->id) {
        $isadmin = true;
        break;
    }
}
$testct_user_admin = $DB->get_record_sql('
    SELECT count(id) as is_admin
    FROM mdl_local_testcentre_useradmin
    WHERE access_level=\'Administrator\'
    AND userid = ?',array($USER->id));

$testct_user = $DB->get_record_sql('
    SELECT count(id) as is_user
    FROM mdl_local_testcentre_useradmin
    WHERE access_level=\'Test Centre\'
    AND userid = ?',array($USER->id));

echo '<ol>';
if($isadmin || $testct_user_admin->is_admin == 1){
    echo '<li><a href="'. $CFG->wwwroot . '/local/testcentre_ms/user_admin.php">User Administration</a></li>';
    show_options();
}
else if($testct_user->is_user == 1){
   //place other options here 
   show_options();
   
}
else{
    echo 'You are not authorized to login';
}
echo '</ol>';

echo $OUTPUT->footer();

function show_options(){
    
    global $CFG;
    
    echo '<li><a href="'. $CFG->wwwroot . '/local/testcentre_ms/tc_pass_admin.php">Test Centre Password Administration</a></li>';
    echo '<li><a href="'. $CFG->wwwroot . '/local/testcentre_ms/student_list.php">Student List</a></li>';
    //echo '<li><a href="'. $CFG->wwwroot . '/local/testcentre_ms/webct_exam_list.php">View list of Webct Exams</a></li>';
    //echo '<li><a href="'. $CFG->wwwroot . '/local/testcentre_ms/comments_and_usage.php">Search the Database for Comments and Usage</a></li>';
    echo '<li><a href="'. $CFG->wwwroot . '/local/testcentre_ms/stat_charts.php">Search the Database for Stats</a></li>';
    
}
?>



    