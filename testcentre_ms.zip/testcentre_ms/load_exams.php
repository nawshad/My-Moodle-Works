<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
//require_once('ldap.php');
global $DB, $USER;
$courseid = $_POST["courseid"];
$operation = $_POST['op'];
//query out all the users and send their lastname,firstname and uleth username

if($operation == 'load_all_exams'){
    $get_exams = $DB->get_records_sql('
                        SELECT mq.id, mq.name 
                        FROM mdl_quiz mq 
                        WHERE course = ?
                        ORDER BY name',array($courseid));
}
else{
    $get_exams = $DB->get_records_sql('
                        SELECT mq.id, mq.name 
                        FROM mdl_quiz mq, mdl_local_testcentre_exam_pass ltep 
                        WHERE course = ?
                        AND mq.id = ltep.examid
                        AND ltep.deleted = 1
                        ORDER BY name',array($courseid));   
}

$i=0;
foreach($get_exams as $get_exam){
    $rows[$i++] = array('label' => $get_exam->name, 
                        'value' =>$get_exam->id);   
}
echo json_encode($rows);



?>
