<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))). '/config.php');
require_once('forms/tc_pass_admin_form.php');

$context = get_context_instance(CONTEXT_SYSTEM);
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
//Create the breadcrumbs
$navlinks = array(
    array(
        'name' => get_string('nav_tc_mn', 'local_testcentre_ms'),
        'link' => $CFG->wwwroot . '/local/testcentre_ms/index.php',
        'type' => 'misc'
    ),
    array(
        'name' => get_string('nav_tc_pass_admin', 'local_testcentre_ms'),
        'link' => '',
        'type' => 'misc'
    ),
);
$nav = build_navigation($navlinks);
//Set page headers.
$PAGE->set_title(get_string('nav_tc_mn', 'local_testcentre_ms'));
$PAGE->set_heading(get_string('nav_tc_mn', 'local_testcentre_ms'));
$PAGE->requires->css('/local/testcentre_ms/styles.css');
$PAGE->requires->js(new moodle_url('js/jquery.dataTables.min.js'));
//$PAGE->requires->js(new moodle_url('js/comboboxwidget.js'));
$PAGE->requires->js(new moodle_url('js/jquery.jeditable.js'));
$PAGE->requires->js(new moodle_url('js/jquery.validate.js'));
$PAGE->requires->js(new moodle_url('js/jquery.dataTables.editable.js'));
//$PAGE->requires->js(new moodle_url('js/utility.js'));
$PAGE->requires->js(new moodle_url('js/tc_pass_admin_events.js'));

//enable require_login option
require_login();
//show header
echo $OUTPUT->header();

$mform = new tc_pass_admin_form() ;
$mform->display();

echo $OUTPUT->footer();

?>
