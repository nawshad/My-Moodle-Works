<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
//require_once('ldap.php');
global $DB, $USER;
//query out all the users and send their lastname,firstname and uleth username
$userids_to_be_deleted = $_POST['checkboxVals'];

foreach($userids_to_be_deleted as $userid){
    $DB->delete_records('local_testcentre_useradmin', array('id' => $userid));
}

echo 'successfully deleted';
    
?>
