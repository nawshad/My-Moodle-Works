<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once(dirname(dirname(dirname(__FILE__))). '/config.php');
require_once('forms/student_list_form.php');
//require_once('locallib.php');
$context = get_context_instance(CONTEXT_SYSTEM);
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
//Create the breadcrumbs
$navlinks = array(
    array(
        'name' => get_string('nav_tc_mn', 'local_testcentre_ms'),
        'link' => $CFG->wwwroot . '/local/testcentre_ms/index.php',
        'type' => 'misc'
    ),
    array(
        'name' => get_string('nav_tc_std_list', 'local_testcentre_ms'),
        'link' => '',
        'type' => 'misc'
    ),
);
$nav = build_navigation($navlinks);
//Set page headers.
$PAGE->set_title(get_string('nav_tc_mn', 'local_testcentre_ms'));
$PAGE->set_heading(get_string('nav_tc_mn', 'local_testcentre_ms'));
//add necessary css and js files
$PAGE->requires->css('/local/testcentre_ms/styles.css');
//$PAGE->requires->js(new moodle_url('js/utility.js'));
$PAGE->requires->js(new moodle_url('js/student_list_events.js'));
//$PAGE->requires->js(new moodle_url('js/jquery.dataTables.min.js'));
$PAGE->requires->js(new moodle_url('js/jquery.dataTables.min.js'));
//$PAGE->requires->js(new moodle_url('js/autogrow.min.js'));
//$PAGE->requires->js(new moodle_url('js/jquery-ui-sliderAccess.js'));
//$PAGE->requires->js(new moodle_url('js/jquery-ui-timepicker-addon.js'));
//$PAGE->requires->js(new moodle_url('js/comboboxwidget.js'));
$PAGE->requires->js(new moodle_url('js/jquery.jeditable.js'));
$PAGE->requires->js(new moodle_url('js/jquery.validate.js'));
$PAGE->requires->js(new moodle_url('js/jquery.dataTables.editable.js'));
//enable require_login option
require_login();
//show header
echo $OUTPUT->header();
//show the useradmin_form
$mform = new useradmin_form() ;
$mform->display();
//create footer of the page
echo $OUTPUT->footer();

?>

