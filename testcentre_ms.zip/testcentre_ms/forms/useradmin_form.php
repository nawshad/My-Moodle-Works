<?php

/**
 * ************************************************************************
 * *                 Test Centre Management System                       **
 * ************************************************************************
 * @package      local                                                   **
 * @subpackage   testcentre_ms                                           **
 * @name         testcentre_ms                                           **
 * @author       Nawshad Farruque           				 **
 *                                                                       **
 * ************************************************************************
 * ************************************************************************/
/**
 * This is the form that a global admin will use to assign department administrators.
 */
require_once("$CFG->libdir/formslib.php");
 
class useradmin_form extends moodleform {
    //Add elements to form
    public function definition() {
        global $CFG;
        $mform = $this->_form; // Don't forget the underscore!
        $mform->addElement('text', 'tc_username', get_string('username','local_testcentre_ms')); // Add elements to your form
        $mform->setType('tc_username', PARAM_NOTAGS);                   
        $rolelist = array('Administrator'=>'Administrator','Test Centre'=>'Test Centre');
        $select = $mform->addElement('select', 'tc_selectrole', get_string('selectrole', 'local_testcentre_ms'), $rolelist);
        //set the default value of combobox as Test Centre
        $mform->setDefault('tc_selectrole', 'Test Centre'); 
        //Create a button for adding user
        $mform->addElement('button', 'tc_add_user', get_string('add_user', 'local_testcentre_ms'));
        //creating the table header
        //wrap the table with a div
        $mform->addElement(html,'<div id = tcUserListTableWrapper class = roundedBorder>');
        $mform->addElement(html,'<table id = tcUserList class = display width = 100% cellpadding="1" style="text-align: left">');
        $mform->addElement(html, '<thead>') ;
        $mform->addElement(html, '<tr>') ;
        $mform->addElement(html, '<th>' . get_string('id_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('select_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('name_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('username_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('access_level_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '</tr>');
        $mform->addElement(html, '</thead>') ;
        $mform->addElement(html, '<tbody>') ;
        //populate the table with Data
        global $DB;
        $get_users_info = $DB->get_records_sql('
                              SELECT id,userid,name, username, access_level
                              FROM mdl_local_testcentre_useradmin
                          ') ;
        foreach($get_users_info as $get_user_info){
            //$mform->addElement(html,"<tr id = ".$get_user_info->id."><td><input type= 'checkbox' name = 'selectCheckBox' value = $get_user_info->id></td><td>$get_user_info->name</td><td>$get_user_info->username</td><td>$get_user_info->access_level</td></tr>") ;
           $mform->addElement(html,"<tr id = $get_user_info->id><td>$get_user_info->id</td><td><input type= 'checkbox' name = 'selectCheckBox' value = $get_user_info->id></td><td>$get_user_info->name</td><td>$get_user_info->username</td><td>$get_user_info->access_level</td></tr>") ;      
        }
        $mform->addElement(html, '</tbody>') ;
        $mform->addElement(html,'</table>'); 
        $mform->addElement(html,'</div>');
        //Creating delete button
        $mform->addElement(html,'<button id = id_tc_delete_user >'.get_string('delete_user', 'local_testcentre_ms').'</button>');

        //$mform->addElement('button', 'tc_delete_user', get_string('delete_user', 'local_testcentre_ms'));  
    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    } 
}

?>

