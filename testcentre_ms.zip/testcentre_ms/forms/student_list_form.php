<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once("$CFG->libdir/formslib.php");
 
class useradmin_form extends moodleform {
    //Add elements to form
    public function definition() {
        global $CFG;
        $mform = $this->_form; // Don't forget the underscore!
        $mform->addElement('password', 'tc_std_list_useridno', get_string('std_list_useridno','local_testcentre_ms')); // Add elements to your form
        $mform->addElement('text', 'tc_std_list_username', get_string('std_list_username','local_testcentre_ms')); 
        $mform->setType('tc_username', PARAM_NOTAGS); 
        //$mform->addElement(html,'<div id = std_list_image_title>Student Image:<div id = std_list_image ></div></div>'); 
        $mform->addElement(html,'<div id = std_list_image></div>');
        //$mform->addElement(html,'<div id = std_list_image_title></div>');
        //echo '<div id = std_list_image_title>Image</div>';
        $mform->addElement('text', 'tc_std_list_exams', get_string('std_list_exams','local_testcentre_ms')); 
        $idlist = array('UofLID'=>'UofL ID #','DriversLicense'=>'Drivers\'s License','Other'=>'Other\'s(Please Specify in the comments)' );
        $select = $mform->addElement('select', 'tc_std_list_selectid', get_string('std_list_selectid', 'local_testcentre_ms'), $idlist);
        //set the default value of combobox as Test Centre
        $mform->setDefault('tc_std_list_selectid', 'Test Centre'); 
        //create machine no text field
        $mform->addElement('text', 'tc_std_list_machineno', get_string('std_list_machineno','local_testcentre_ms')); 
        //create textarea for comments field
        $mform->addElement('textarea', 'tc_std_list_comments', get_string('std_list_comments','local_testcentre_ms')); 
        //Create a button for adding user
        $mform->addElement('button', 'tc_std_list_open_std', get_string('std_list_open_std', 'local_testcentre_ms'));
        //creating the table header
        //wrap the table with a div
        $mform->addElement(html,'<div id = tcStdListTableWrapper class = roundedBorder>');
        $mform->addElement(html,'<table id = tcStdList class = display width = 100% cellpadding="1" style="text-align: left">');
        $mform->addElement(html, '<thead>') ;
        $mform->addElement(html, '<tr>') ;
        $mform->addElement(html, '<th>' . get_string('std_list_id_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('select_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('std_list_username_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('std_list_course_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('std_list_machine_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('std_list_signedup_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('std_list_comments_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '</tr>');
        $mform->addElement(html, '</thead>') ;
        $mform->addElement(html, '<tbody>') ;
        //populate the table with Data
        global $DB;
        $get_stds_info = $DB->get_records_sql('
                              SELECT tse.id, tse.username, mc.fullname||\'-\'||mq.name as coursename, tse.machine_no, tse.time_signed, tse.comments
                              FROM mdl_local_testcentre_std_entry tse, mdl_course mc, mdl_quiz mq
                              WHERE mq.course = mc.id  
                              AND tse.examid = mq.id 
                              AND deleted = 0
                          ') ;
        foreach($get_stds_info as $get_std_info){
           $timesigned = date('Y-m-d H:i:s',$get_std_info->time_signed);
            //$mform->addElement(html,"<tr id = ".$get_user_info->id."><td><input type= 'checkbox' name = 'selectCheckBox' value = $get_user_info->id></td><td>$get_user_info->name</td><td>$get_user_info->username</td><td>$get_user_info->access_level</td></tr>") ;
           $mform->addElement(html,"<tr id = $get_std_info->id><td>$get_std_info->id</td><td><input type= 'checkbox' name = 'selectCheckBox' value = $get_std_info->id></td><td>$get_std_info->username</td><td>$get_std_info->coursename</td><td>$get_std_info->machine_no</td><td>$timesigned</td><td>$get_std_info->comments</td></tr>") ;      
        }
        $mform->addElement(html, '</tbody>') ;
        $mform->addElement(html,'</table>'); 
        $mform->addElement(html,'</div>');
        $mform->addElement(html,'<button id = id_tc_close_std class = std_list_button>'.get_string('std_list_close_record', 'local_testcentre_ms').'</button>');
        //Creating delete button
        //echo '<button class = std_list_button id = btnDeleteRow>'.get_string('std_list_close_record', 'local_testcentre_ms').'</button>';
    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    } 
}

?>