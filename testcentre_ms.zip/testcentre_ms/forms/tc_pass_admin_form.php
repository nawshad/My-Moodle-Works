<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once("$CFG->libdir/formslib.php");
 
class tc_pass_admin_form extends moodleform {
    //Add elements to form
    public function definition() {
        global $CFG;
        $mform = $this->_form; // Don't forget the underscore!
        $mform->addElement(html,'<input type="hidden" name="courseid" id="tc_courseid">');
        $mform->addElement(html,'<input type="hidden" name="examid" id="tc_examid">');
        
        //wrap the table with a div
        $mform->addElement(html,'<div id = tcExamListTableWrapper class = roundedBorder>');
        $mform->addElement(html,'<table id = tcExamList width = 95% cellpadding="1" style="text-align: left" class = display>');
        $mform->addElement(html, '<thead>');
        $mform->addElement(html, '<tr>');
        $mform->addElement(html, '<th>' . get_string('exam_pass_id_header', 'local_testcentre_ms') .'</th>');
        $mform->addElement(html, '<th>' . get_string('select_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('course_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('exam_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('openingdate_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('closingdate_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('password_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '<th>' . get_string('notes_header', 'local_testcentre_ms') . '</th>');
        $mform->addElement(html, '</tr>');
        $mform->addElement(html, '</thead>');
        $mform->addElement(html, '<tbody>');
        
        global $DB;
        $get_exams_info = $DB->get_records_sql('
                                SELECT ltep.id, mc.fullname as coursename, 
                                        mq.name as examname, 
                                        mq.timeopen as opening_date, 
                                        mq.timeclose as closing_date, 
                                        ltep.password as password, 
                                        ltep.notes as notes
                                FROM    mdl_local_testcentre_exam_pass ltep, 
                                        mdl_quiz mq, mdl_course mc
                                WHERE ltep.deleted = 0
                                AND mq.id = ltep.examid
                                AND mq.course = mc.id');
        
        foreach($get_exams_info as $get_exam_info){
            if($get_exam_info->opening_date>0 && $get_exam_info->closing_date>0){
                $opening_date = date('Y-m-d H:i:s',$get_exam_info->opening_date);
                $closing_date = date('Y-m-d H:i:s',$get_exam_info->closing_date);
                //$mform->addElement(html,"<tr id = $get_exam_info->id ><td>$get_exam_info->id</td><td><input type= 'checkbox' name = 'tc_exam_pass_selectCheckBox' value = $get_exam_info->id></td><td>$get_exam_info->coursename</td><td>$get_exam_info->examname</td><td>$opening_date</td><td>$closing_date</td><td>$get_exam_info->password</td><td>$get_exam_info->notes</td></tr>") ;                 
            } 
            else{
                $opening_date = 'Not Yet Set';
                $closing_date = 'Not Yet Set';
            }
            $mform->addElement(html,"<tr id = $get_exam_info->id><td>$get_exam_info->id</td><td><input type= 'checkbox' name = 'tc_exam_pass_selectCheckBox' value = $get_exam_info->id></td><td>$get_exam_info->coursename</td><td>$get_exam_info->examname</td><td>$opening_date</td><td>$closing_date</td><td>$get_exam_info->password</td><td>$get_exam_info->notes</td></tr>") ;                 
        }
        $mform->addElement(html, '</tbody>') ;
        $mform->addElement(html,'</table>'); 
        $mform->addElement(html,'</div>');
        
        echo '<button id = btnAddNewRow>'.get_string('add_record', 'local_testcentre_ms').'</button>';
        echo '<button class = tc_pass_admin_button id = id_tc_close_exam>'.get_string('close_exam', 'local_testcentre_ms').'</button>';
        echo '<button id = btnOpenRow>'.get_string('open_exam', 'local_testcentre_ms').'</button>';
        
    }
    function validation($data, $files) {
        return array();
    } 
}

?>
