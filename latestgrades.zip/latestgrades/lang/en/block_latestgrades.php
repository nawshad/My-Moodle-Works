<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Latest Grades';
$string['latestgrades:addinstance'] = 'Add a new Latest Grades block';
$string['latestgrades:myaddinstance'] = 'Add a new Latest Grades block to the My Moodle page';

?>
